package com.mygdx.game;

public interface ScoreBoard {
    void readFile();
}
