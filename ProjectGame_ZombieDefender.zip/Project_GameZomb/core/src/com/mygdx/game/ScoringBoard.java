package com.mygdx.game;

public interface ScoringBoard {
    void writeToLeaderBoard(int score);
}
